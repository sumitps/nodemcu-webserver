#ifndef LedREST_h
#define LedREST_h

#include "Arduino.h"

class LedREST
{
  public:
    LedREST(int pin);
    boolean on();
    boolean off();
  private:
    int _pin;
};

#endif